/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Visual;

import ParteLogica.Player;
import ParteLogica.Script;
import ParteLogica.Tablero;
import java.awt.Label;
import java.util.HashSet;
import java.util.Set;
import javax.swing.ImageIcon;
import javax.swing.JLabel;


/**
 *
 * @author josem
 */
public class Pantalla extends javax.swing.JFrame {

    int cont;
    boolean enc;
    private Tablero t;
    private Player p1;
    private Player p2;
    private int ganadas;
    private boolean b1;
    private boolean b2;
    private boolean b3;
    private boolean b4;
    private boolean b5;
    private boolean b6;
    private boolean b7;
    private boolean b8;
    private boolean b9;
    int ganador;
    
    public Pantalla() {
        initComponents();
        t=new Tablero();
         p1=new Player(true);
        p2=new Player(false);
        ganadas=0;
        cont=0;
        enc=false;
        ganador=0;
        setPantalla();
        resetButton();
    }
    
    public Pantalla(Tablero t, Player p1, Player p2, int ganadas, boolean enc, int ganador){
        initComponents();
        this.t=t;
         this.p1=p1;
        this.p2=p2;
        this.ganadas=ganadas;
        this.enc=enc;
        this.ganador=ganador;
        setPantalla();
        resetButton();
    }

    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        unoUno = new javax.swing.JButton();
        unoDos = new javax.swing.JButton();
        unoTres = new javax.swing.JButton();
        dosUno = new javax.swing.JButton();
        dosDos = new javax.swing.JButton();
        dosTres = new javax.swing.JButton();
        tresUno = new javax.swing.JButton();
        tresDos = new javax.swing.JButton();
        tresTres = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        victoriasP2 = new javax.swing.JLabel();
        victoriasP1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Fondo.setBackground(new java.awt.Color(255, 255, 255));
        Fondo.setMaximumSize(new java.awt.Dimension(800, 500));
        Fondo.setMinimumSize(new java.awt.Dimension(800, 500));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        unoUno.setBackground(new java.awt.Color(102, 0, 102));
        unoUno.setForeground(new java.awt.Color(102, 0, 102));
        unoUno.setBorderPainted(false);
        unoUno.setContentAreaFilled(false);
        unoUno.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        unoUno.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                unoUnoMouseClicked(evt);
            }
        });
        unoUno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                unoUnoActionPerformed(evt);
            }
        });
        jPanel1.add(unoUno, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 5, 144, 144));

        unoDos.setBorderPainted(false);
        unoDos.setContentAreaFilled(false);
        unoDos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        unoDos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                unoDosActionPerformed(evt);
            }
        });
        jPanel1.add(unoDos, new org.netbeans.lib.awtextra.AbsoluteConstraints(155, 5, 144, 144));

        unoTres.setBorderPainted(false);
        unoTres.setContentAreaFilled(false);
        unoTres.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        unoTres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                unoTresActionPerformed(evt);
            }
        });
        jPanel1.add(unoTres, new org.netbeans.lib.awtextra.AbsoluteConstraints(305, 5, 140, 144));

        dosUno.setBorderPainted(false);
        dosUno.setContentAreaFilled(false);
        dosUno.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        dosUno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dosUnoActionPerformed(evt);
            }
        });
        jPanel1.add(dosUno, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 155, 144, 144));

        dosDos.setBorderPainted(false);
        dosDos.setContentAreaFilled(false);
        dosDos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        dosDos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dosDosActionPerformed(evt);
            }
        });
        jPanel1.add(dosDos, new org.netbeans.lib.awtextra.AbsoluteConstraints(155, 155, 144, 144));

        dosTres.setContentAreaFilled(false);
        dosTres.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        dosTres.setDefaultCapable(false);
        dosTres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dosTresActionPerformed(evt);
            }
        });
        jPanel1.add(dosTres, new org.netbeans.lib.awtextra.AbsoluteConstraints(305, 155, 140, 144));

        tresUno.setBorderPainted(false);
        tresUno.setContentAreaFilled(false);
        tresUno.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tresUno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tresUnoActionPerformed(evt);
            }
        });
        jPanel1.add(tresUno, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 305, 144, 140));

        tresDos.setBorderPainted(false);
        tresDos.setContentAreaFilled(false);
        tresDos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tresDos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tresDosActionPerformed(evt);
            }
        });
        jPanel1.add(tresDos, new org.netbeans.lib.awtextra.AbsoluteConstraints(155, 305, 144, 140));

        tresTres.setBorderPainted(false);
        tresTres.setContentAreaFilled(false);
        tresTres.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tresTres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tresTresActionPerformed(evt);
            }
        });
        jPanel1.add(tresTres, new org.netbeans.lib.awtextra.AbsoluteConstraints(305, 305, 140, 140));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/cuadradoProyecto.jpg"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 450));

        Fondo.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 20, 450, 450));

        victoriasP2.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        victoriasP2.setForeground(new java.awt.Color(0, 0, 0));
        victoriasP2.setText("Victorias P2:  0");
        Fondo.add(victoriasP2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 180, -1));

        victoriasP1.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        victoriasP1.setForeground(new java.awt.Color(0, 0, 0));
        victoriasP1.setText("Victorias P1:  0");
        Fondo.add(victoriasP1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 180, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, 816, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, 516, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void resetButton(){
        b1=false;
        b2=false;
        b3=false;
        b4=false;
        b5=false;
        b6=false;
        b7=false;
        b8=false;
        b9=false;
        p1.setTurno(true);
        p2.setTurno(false);
        ganador=0;
        enc=false;
        resetImages();
    }
    
    private void desactivarTablero(){
        unoUno.setVisible(false);
       unoDos.setVisible(false);
       unoTres.setVisible(false);
       dosUno.setVisible(false);
       dosDos.setVisible(false);
       dosTres.setVisible(false);
       tresUno.setVisible(false);
       tresDos.setVisible(false);
       tresTres.setVisible(false);
    }
    
    private void setPantalla(){
       victoriasP1.setText("Victorias P1:  "+p1.getVictorias());
       victoriasP1.setVisible(true);
       victoriasP2.setText("Victorias P2:  "+p2.getVictorias());
       victoriasP2.setVisible(true);
       unoUno.setVisible(true);
       unoDos.setVisible(true);
       unoTres.setVisible(true);
       dosUno.setVisible(true);
       dosDos.setVisible(true);
       dosTres.setVisible(true);
       tresUno.setVisible(true);
       tresDos.setVisible(true);
       tresTres.setVisible(true);
    }
    
    
    private void partida(int casilla){
        int turno=0;
        if(p1.isTurno()==true){
            turno=1;
        t.addMovement(1, casilla);
            p2.setTurno(true);
            p1.setTurno(false);
            
    }else{
        if(p2.isTurno()==true){
            turno=2;
            t.addMovement(2, casilla);
            p2.setTurno(false);
            p1.setTurno(true);
            
        }
    }
    setImagen(casilla, turno);
    cont++;
    
    }
    private void setImagen(int casilla, int turno){
        ImageIcon circulo=new ImageIcon("src/imagenes/circulopng.png");
        ImageIcon equis=new ImageIcon("src/imagenes/equixpng.png");
        if(turno==1){
           switch(casilla){
               case 1: 
                   unoUno.setIcon(equis);
                   break;
               case 2:
                   unoDos.setIcon(equis);
                   break;
               case 3:
                   unoTres.setIcon(equis);
                   break;
               case 4:
                   dosUno.setIcon(equis);
                   break;
               case 5:
                   dosDos.setIcon(equis);
                   break;
               case 6:
                   dosTres.setIcon(equis);
                   break;
               case 7:
                   tresUno.setIcon(equis);
                   break;
               case 8:
                   tresDos.setIcon(equis);
                   break;
               case 9:
                   tresTres.setIcon(equis);
                   break;
                   
           }
        }else{
            if(turno==2){
                switch(casilla){
               case 1: 
                   unoUno.setIcon(circulo);
                   break;
               case 2:
                   unoDos.setIcon(circulo);
                   break;
               case 3:
                   unoTres.setIcon(circulo);
                   break;
               case 4:
                   dosUno.setIcon(circulo);
                   break;
               case 5:
                   dosDos.setIcon(circulo);
                   break;
               case 6:
                   dosTres.setIcon(circulo);
                   break;
               case 7:
                   tresUno.setIcon(circulo);
                   break;
               case 8:
                   tresDos.setIcon(circulo);
                   break;
               case 9:
                   tresTres.setIcon(circulo);
                   break;
            }
        }
    }
    }
    private void resetImages(){ 
                   unoUno.setIcon(null);
                   unoDos.setIcon(null);
                   unoTres.setIcon(null);
                   dosUno.setIcon(null);
                   dosDos.setIcon(null);
                   dosTres.setIcon(null);

                   tresUno.setIcon(null);

                   tresDos.setIcon(null);
                
                   tresTres.setIcon(null);
                   
    }
        private void siguiente(){
        int desision=t.compruebaGanador();
        if(desision==-2){
                ganador=-1;
                Elector ini=new Elector(t,p1,p2,ganadas,enc,ganador);
                t.resetTablero();
                resetButton();
                ini.setVisible(true);
                this.dispose();
                ini.setLocationRelativeTo(null);
        }
        else{
            if(desision==1){
                p1.setVictorias(p1.getVictorias()+1);
                victoriasP1.setText("Victorias P1:  "+p1.getVictorias());
                victoriasP1.setVisible(true);
                victoriasP2.setVisible(false);
                ganador=1;
                Elector ini=new Elector(t,p1,p2,ganadas,enc,ganador);
                resetButton();
                t.resetTablero();
                ini.setVisible(true);
                this.dispose();
                ini.setLocationRelativeTo(null);
            }else{
                if(desision==2){
                
                p2.setVictorias(p2.getVictorias()+1);
                victoriasP2.setText("Victorias P2:  "+p2.getVictorias());
                victoriasP1.setVisible(false);
                victoriasP2.setVisible(true);
                ganador=2;
                Elector ini=new Elector(t,p1,p2,ganadas,enc,ganador);
                resetButton();
                t.resetTablero();
                ini.setVisible(true);
                this.dispose();
                ini.setLocationRelativeTo(null);
                }
            }
            
        }
        setPantalla();
    }
    private void unoUnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_unoUnoActionPerformed
        if(!b1){
        partida(1);

        b1=true;
        siguiente();
        }
    }//GEN-LAST:event_unoUnoActionPerformed

    private void tresDosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tresDosActionPerformed
        if(!b8){
        partida(8);
        b8=true;
        siguiente();
        }
    }//GEN-LAST:event_tresDosActionPerformed

    private void unoUnoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_unoUnoMouseClicked
        
    }//GEN-LAST:event_unoUnoMouseClicked

    private void unoDosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_unoDosActionPerformed
        if(!b2){
        partida(2);
 
        b2=true;
        siguiente();
        }
    }//GEN-LAST:event_unoDosActionPerformed

    private void unoTresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_unoTresActionPerformed
        if(!b3){
        partida(3);

        b3=true;
        siguiente();
        }
    }//GEN-LAST:event_unoTresActionPerformed

    private void dosUnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dosUnoActionPerformed
        if(!b4){
        partida(4);

        b4=true;
        siguiente();
        }
    }//GEN-LAST:event_dosUnoActionPerformed

    private void dosDosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dosDosActionPerformed
        if(!b5){
        partida(5);

        b5=true;
        siguiente();
        }
    }//GEN-LAST:event_dosDosActionPerformed

    private void dosTresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dosTresActionPerformed
        if(!b6){
        partida(6);

        b6=true;
        siguiente();
        }
    }//GEN-LAST:event_dosTresActionPerformed

    private void tresUnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tresUnoActionPerformed
        if(!b7){
        partida(7);

        b7=true;
        siguiente();
        }
    }//GEN-LAST:event_tresUnoActionPerformed

    private void tresTresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tresTresActionPerformed
        if(!b9){
        partida(9);

        b9=true;
        siguiente();
        }
    }//GEN-LAST:event_tresTresActionPerformed
    
    
    /**
     * @param args the command line arguments
     */

    public int getGanador() {
        return ganador;
    }

    public void setGanador(int ganador) {
        this.ganador = ganador;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Fondo;
    private javax.swing.JButton dosDos;
    private javax.swing.JButton dosTres;
    private javax.swing.JButton dosUno;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton tresDos;
    private javax.swing.JButton tresTres;
    private javax.swing.JButton tresUno;
    private javax.swing.JButton unoDos;
    private javax.swing.JButton unoTres;
    private javax.swing.JButton unoUno;
    private javax.swing.JLabel victoriasP1;
    private javax.swing.JLabel victoriasP2;
    // End of variables declaration//GEN-END:variables
}


