
package ParteLogica;

import Visual.PantallaInicio;


public class Main {

    
    public static void main(String[] args) {
        PantallaInicio panta= new PantallaInicio();
        panta.setVisible(true);
        panta.setLocationRelativeTo(null);
    }
    
}
