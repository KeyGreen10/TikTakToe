
package ParteLogica;



public class Tablero {
    private int[][] tablero;
    private  boolean ganar;
    int contador;
    public Tablero() {
        tablero=new int[3][3];
        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                tablero[i][j]=-1;
            }
        }
       resetTablero();
       ganar=false; 
       contador=0;
    }
    
    
     public boolean addMovement(int player, int casilla) {
        int x = -1, y = -1;

        if (casilla == 1) {
            x = 0;
            y = 0;
        } else if (casilla == 2) {
            x = 0;
            y = 1;
        } else if (casilla == 3) {
            x = 0;
            y = 2;
        } else if (casilla == 4) {
            x = 1;
            y = 0;
        } else if (casilla == 5) {
            x = 1;
            y = 1;
        } else if (casilla == 6) {
            x = 1;
            y = 2;
        } else if (casilla == 7) {
            x = 2;
            y = 0;
        } else if (casilla == 8) {
            x = 2;
            y = 1;
        } else if (casilla == 9) {
            x = 2;
            y = 2;
        }

        if (tablero[x][y] == -1) {
            tablero[x][y] = player;
            return true;
        } else {
            return false;
        }
    }
    
    public int compruebaGanador() {
    /*
        2=ganan las o
        1=ganan las x
        -2=empate
         */
        contador++;
        int cont = -1;
        if (contador < 9) {
            if (tablero[0][0] == 2 && tablero[0][1] == 2 && tablero[0][2] == 2 || tablero[1][0] == 2 && tablero[1][1] == 2 && tablero[1][2] == 2
                    || tablero[2][0] == 2 && tablero[2][1] == 2 && tablero[2][2] == 2 || tablero[0][0] == 2 && tablero[1][1] == 2 && tablero[2][2] == 2
                    || tablero[0][0] == 2 && tablero[1][0] == 2 && tablero[2][0] == 2 || tablero[0][1] == 2 && tablero[1][1] == 2 && tablero[2][1] == 2
                    || tablero[0][2] == 2 && tablero[1][2] == 2 && tablero[2][2] == 2 || tablero[2][0] == 2 && tablero[1][1] == 2 && tablero[0][2] == 2) {
                cont = 2;
            } else if (tablero[0][0] == 1 && tablero[0][1] == 1 && tablero[0][2] == 1 || tablero[1][0] == 1 && tablero[1][1] == 1 && tablero[1][2] == 1
                    || tablero[2][0] == 1 && tablero[2][1] == 1 && tablero[2][2] == 1 || tablero[0][0] == 1 && tablero[1][1] == 1 && tablero[2][2] == 1
                    || tablero[0][0] == 1 && tablero[1][0] == 1 && tablero[2][0] == 1 || tablero[0][1] == 1 && tablero[1][1] == 1 && tablero[2][1] == 1
                    || tablero[0][2] == 1 && tablero[1][2] == 1 && tablero[2][2] == 1 || tablero[2][0] == 1 && tablero[1][1] == 1 && tablero[0][2] == 1) {
                cont = 1;
            }
        } else {
            cont = -2;
        }
        return cont;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }
    
    public void addContador(){
        this.contador++;
    }

    public int[][] getTablero() {
        return tablero;
    }

    public void setTablero(int[][] tablero) {
        this.tablero = tablero;
    }
    
    public void resetTablero() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                tablero[i][j] = -1;
            }
        }
        contador=0;
    }
}
