
package ParteLogica;

import Visual.Pantalla;
import java.awt.event.ActionListener;
import java.util.HashSet;
import java.util.Set;

public class Script {
    
    private Player p2;
    private Player p1;
    private Tablero t;
    private Pantalla p;
    int cont;
    boolean enc;
    
    public Script(){
        p1=new Player(true);
        p2=new Player(false);
        cont=0;
        enc=false;
    }
    
    public void partida(int casilla){
    
    if(p1.isTurno()==true){
        t.addMovement(1, casilla);
            p2.setTurno(true);
            p1.setTurno(false);
            t.addContador();
    }else{
        if(p2.isTurno()==true){
            t.addMovement(2, casilla);
            p2.setTurno(false);
            p1.setTurno(true);
            t.addContador();
        }
    }
    cont++;
    
}
  

    public int getCont() {
        return cont;
    }

    public void setCont(int cont) {
        this.cont = cont;
    }

    public boolean isEnc() {
        return enc;
    }

    public void setEnc(boolean enc) {
        this.enc = enc;
    }
    
    
    }

    
